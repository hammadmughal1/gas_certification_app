part of 'login_bloc.dart';

@immutable
abstract class LoginState {}

class LoginInitial extends LoginState {}


class LoginBtnTapState extends LoginState{
  final GeneralResponse response;
  LoginBtnTapState(this.response);
}

class LoginBtnTapSuccessState extends LoginState{
  final GeneralResponse response;
  LoginBtnTapSuccessState(this.response);
}


class LoginEmailValidatorState extends LoginState {
  final String validationMessage ;
  LoginEmailValidatorState(this.validationMessage);
}


class LoginPasswordValidatorState extends LoginState {
  final String validationMessage ;
  LoginPasswordValidatorState(this.validationMessage);
}

class LoadingState extends LoginState{

}
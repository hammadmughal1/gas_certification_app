part of 'login_bloc.dart';

@immutable
abstract class LoginEvent {}

class LoginBtnTapEvent extends LoginEvent{

  final String email ;
  final String password;
  LoginBtnTapEvent( this.email , this. password);
}

class LoginEmailValidatorEvent extends LoginEvent{
  final String email ;
  LoginEmailValidatorEvent(this.email);
}

class LoginNameValidatorEvent extends LoginEvent{
  final String name ;
  LoginNameValidatorEvent(this.name);
}

class LoginPasswordValidatorEvent extends LoginEvent{
  final String password ;
  LoginPasswordValidatorEvent(this.password);
}

class LoginLoadingEvent extends LoginEvent{}

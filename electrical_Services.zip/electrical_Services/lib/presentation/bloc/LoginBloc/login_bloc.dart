import 'dart:async';

import 'package:bloc/bloc.dart';
import 'package:meta/meta.dart';

import '../../../base/validators.dart';
import '../../../manager/manager.dart';
import '../../../models/GeneralResponse.dart';

part 'login_event.dart';
part 'login_state.dart';

class LoginBloc extends Bloc<LoginEvent, LoginState> {
  LoginBloc() : super(LoginInitial());

    @override
    Stream<LoginState> mapEventToState(LoginEvent event) async* {
      switch (event.runtimeType) {
      case LoginBtnTapEvent:
        yield* _mapLoginWithEmailPassEventToState(
            event as LoginBtnTapEvent);
        break;
        case LoginLoadingEvent:
          yield LoadingState();
          break;
        case LoginEmailValidatorEvent:
          yield* _mapLoginEmailValidator(event as LoginEmailValidatorEvent);
          break;
        case LoginPasswordValidatorEvent:
          yield* _mapLoginPasswordValidator(
              event as LoginPasswordValidatorEvent);
          break;
      }
    }

    Stream<LoginState> _mapLoginEmailValidator(
        LoginEmailValidatorEvent event) async* {
      String emailValidationError = "";

      /// check if email is valid
      emailValidationError =
          GasCertificationValidators.emailValidatorMulti(event.email.trim());
      yield LoginEmailValidatorState(emailValidationError);
    }



    Stream<LoginState> _mapLoginPasswordValidator(
        LoginPasswordValidatorEvent event) async* {
      String emailValidationError = "";

      /// check if email is valid
      emailValidationError =
          GasCertificationValidators.passwordValidator(event.password.trim());
      yield LoginPasswordValidatorState(emailValidationError);
    }


    Stream<LoginState> _mapLoginWithEmailPassEventToState(
        LoginBtnTapEvent event) async* {
      GeneralResponse response = await manager.authManager
          .signInWithEmailAndPassword(event.email, event.password);
      if(response?.errorMessage == ""){
        yield LoginBtnTapSuccessState(response);
      }else{
        yield LoginBtnTapState(response);
      }

    }
  }
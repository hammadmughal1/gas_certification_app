part of 'sign_up_bloc.dart';

@immutable
abstract class SignUpState {}

class SignUpInitial extends SignUpState {}

class SignUpBtnTapState extends SignUpState{
  final GeneralResponse response;
  SignUpBtnTapState(this.response);
}
class SignUpBtnSuccessTapState extends SignUpState{
  final GeneralResponse response;
  SignUpBtnSuccessTapState(this.response);
}

class SignUpEmailValidatorState extends SignUpState {
  final String validationMessage ;
  SignUpEmailValidatorState(this.validationMessage);
}

class SignUpNameValidatorState extends SignUpState {
  final String validationMessage ;
  SignUpNameValidatorState(this.validationMessage);
}
class SignUpPasswordValidatorState extends SignUpState {
  final String validationMessage ;
  SignUpPasswordValidatorState(this.validationMessage);
}

class SignUpConfirmPasswordValidatorState extends SignUpState {
  final String validationMessage ;
  SignUpConfirmPasswordValidatorState(this.validationMessage);
}
class LoadingState extends SignUpState{}
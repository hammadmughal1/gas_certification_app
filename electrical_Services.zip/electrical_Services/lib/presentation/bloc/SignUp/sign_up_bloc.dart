import 'dart:async';

import 'package:bloc/bloc.dart';
import 'package:dio/dio.dart';
import 'package:electrical_services/base/validators.dart';
import 'package:meta/meta.dart';
import 'package:electrical_services/manager/manager.dart';
import 'package:electrical_services/models/GeneralResponse.dart';
import 'package:flutter/cupertino.dart';

part 'sign_up_event.dart';

part 'sign_up_state.dart';


class SignUpBloc extends Bloc<SignUpEvent, SignUpState> {
  SignUpBloc()
      : super(SignUpInitial());

  @override
  Stream<SignUpState> mapEventToState(SignUpEvent event) async* {
    switch (event.runtimeType) {
      case SignUpBtnTapEvent:
        yield* _mapSignUpWithEmailPassEventToState(
            event as SignUpBtnTapEvent);
        break;
      case SignUpLoadingEvent:
        yield LoadingState();
        break;
      case SignUpEmailValidatorEvent:
        yield* _mapSignUpEmailValidator(event as SignUpEmailValidatorEvent);
        break;
      case SignUpNameValidatorEvent:
        yield* _mapSignUpNameValidator(event as SignUpNameValidatorEvent);
        break;
      case SignUpPasswordValidatorEvent:
        yield* _mapSignUpPasswordValidator(event as SignUpPasswordValidatorEvent);
        break;
      case SignUpConfirmPasswordValidatorEvent:
        yield* _mapSignUpConfirmPasswordValidator(event as SignUpConfirmPasswordValidatorEvent);
        break;
    }
  }

  Stream<SignUpState> _mapSignUpEmailValidator(
      SignUpEmailValidatorEvent event) async* {
    String emailValidationError = "";

      /// check if email is valid
      emailValidationError =
          GasCertificationValidators.emailValidatorMulti(event.email.trim());
    yield SignUpEmailValidatorState(emailValidationError);
  }

  Stream<SignUpState> _mapSignUpNameValidator(
      SignUpNameValidatorEvent event) async* {
    String emailValidationError = "";

    /// check if email is valid
    emailValidationError =
        GasCertificationValidators.requiredValidator(event.name.trim());
    yield SignUpNameValidatorState(emailValidationError);
  }


  Stream<SignUpState> _mapSignUpPasswordValidator(
      SignUpPasswordValidatorEvent event) async* {
    String emailValidationError = "";

    /// check if email is valid
    emailValidationError =
        GasCertificationValidators.passwordValidator(event.password.trim());
    yield SignUpPasswordValidatorState(emailValidationError);
  }

  Stream<SignUpState> _mapSignUpConfirmPasswordValidator(
      SignUpConfirmPasswordValidatorEvent event) async* {
    String emailValidationError = "";

    /// check if email is valid
    if(event.checkPassword != event.password){
      emailValidationError = "Passwords does not match.";
    }
    yield SignUpConfirmPasswordValidatorState(emailValidationError);
  }


  Stream<SignUpState> _mapSignUpWithEmailPassEventToState(
    SignUpBtnTapEvent event) async* {
    yield LoadingState();
  GeneralResponse response = await manager.authManager
      .signUpWithEmailAndPassword(event.name, event.email, event.password);

    if(response.errorMessage == ""){
     yield SignUpBtnTapState(response);
    }
    else{
      yield SignUpBtnTapState(response);
    }

}}
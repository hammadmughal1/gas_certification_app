part of 'sign_up_bloc.dart';

@immutable
abstract class SignUpEvent {


}

class SignUpBtnTapEvent extends SignUpEvent{
final String name ;
final String email ;
final String password;
  SignUpBtnTapEvent(this.name , this.email , this. password);
}

class SignUpEmailValidatorEvent extends SignUpEvent{
  final String email ;
  SignUpEmailValidatorEvent(this.email);
}

class SignUpNameValidatorEvent extends SignUpEvent{
  final String name ;
  SignUpNameValidatorEvent(this.name);
}

class SignUpPasswordValidatorEvent extends SignUpEvent{
  final String password ;
  SignUpPasswordValidatorEvent(this.password);
}

class SignUpConfirmPasswordValidatorEvent extends SignUpEvent{
  final String password ;
  final String checkPassword;
  SignUpConfirmPasswordValidatorEvent(this.password, this.checkPassword);
}

class SignUpLoadingEvent extends SignUpEvent{}

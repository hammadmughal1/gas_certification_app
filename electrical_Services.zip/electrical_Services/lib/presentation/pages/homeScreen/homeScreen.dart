import 'package:electrical_services/base/routes.dart';
import 'package:electrical_services/presentation/widgets/appbar.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({Key? key}) : super(key: key);

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: body(context),
    );
  }
}

Widget body(context) {
  return Container(
    width: MediaQuery.of(context).size.width,
    height: MediaQuery.of(context).size.height,
    child: Column(
      children: <Widget>[
        appBar(context),
        const SizedBox(height: 20,),
        tilesBody(context),
      ],
    ),
  );
}

Widget appBar(context){
  return GasCertificationAppBar.gasCertificationBar(isHomeScreen : true ,context: context , backgroundColor: Colors.lightBlue );
}

Widget tilesBody(context){
  return Padding(
    padding: const EdgeInsets.all(8.0),
    child: Column(
      children: [
        ListTile(
          onTap: () => Navigator.of(context).pushNamed(AppRoutes.recordScreen),
          onLongPress: (){

          },
          shape: RoundedRectangleBorder(
            side:  const BorderSide(color: Colors.lightBlue, width: 2),
            borderRadius: BorderRadius.circular(15),
          ),
          leading: const CircleAvatar(
            backgroundColor: Colors.blue,
            child: Text('1'),
          ),
          title: const Text('New Records'),
          subtitle:const Text('Create Certificates here.'),

        ),
        const SizedBox(height: 20,),
        ListTile(
          onLongPress: (){

          },
          shape: RoundedRectangleBorder(
            side:  const BorderSide(color: Colors.lightBlue, width: 2),
            borderRadius: BorderRadius.circular(15),
          ),
          leading: const CircleAvatar(
            backgroundColor: Colors.blue,
            child: Text('1'),
          ),
          title: const Text('Jobs'),
          subtitle:const Text('Check our jobs here'),

        ),
      ],
    ),
  );
}
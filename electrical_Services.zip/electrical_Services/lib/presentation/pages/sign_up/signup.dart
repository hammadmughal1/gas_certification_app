import 'package:electrical_services/base/routes.dart';
import 'package:electrical_services/models/GeneralResponse.dart';
import 'package:electrical_services/presentation/bloc/SignUp/sign_up_bloc.dart';
import 'package:electrical_services/presentation/widgets/CustomTextField.dart';
import 'package:electrical_services/presentation/widgets/IndicatorWidgets.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

class SignUp extends StatefulWidget {
  const SignUp({Key? key}) : super(key: key);

  @override
  State<SignUp> createState() => _SignUpState();
}

class _SignUpState extends State<SignUp> {
  late SignUpBloc _signUpBloc;
  TextEditingController? nameController;
  TextEditingController? emailController;
  TextEditingController? passwordController;
  TextEditingController? confirmPasswordController;
  String emailErrorMessage = "";
  String nameErrorMessage = "";
  String passwordErrorMessage = "";
  String confirmPasswordErrorMessage = "";

  @override
  void initState() {
    emailController = TextEditingController();
    passwordController = TextEditingController();
    nameController = TextEditingController();

    super.initState();
  }

  @override
  void dispose() {
    // TODO: implement dispose
    _signUpBloc.close();
    emailController!.dispose();
    passwordController!.dispose();
    nameController!.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return BlocProvider(
      create: (contexts) {
        return SignUpBloc();
      },
      child: Scaffold(
        body: _buildPageContent(),
      ),
    );
  }
  void sendToDashboard(){
    Navigator.of(context)
        .pushReplacementNamed(AppRoutes.homeScreen, arguments: null);
  }

  Widget _buildPageContent() {
    return BlocListener<SignUpBloc, SignUpState>(listener: (context, state) {
      switch (state.runtimeType) {
        case SignUpBtnTapState:
          ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
            content: Text("Please give right credentials"),
          ));
          break;
        case SignUpBtnSuccessTapState:
          sendToDashboard();
          break;
        case SignUpEmailValidatorState:
          emailErrorMessage = (state as SignUpEmailValidatorState).validationMessage;
          break;
        case SignUpNameValidatorState:
          nameErrorMessage =  (state as SignUpNameValidatorState).validationMessage;
          break;
        case SignUpPasswordValidatorState:
          passwordErrorMessage =  (state as SignUpPasswordValidatorState).validationMessage;
          break;
        case SignUpConfirmPasswordValidatorState:
          confirmPasswordErrorMessage =  (state as SignUpConfirmPasswordValidatorState).validationMessage;
          break;
        case LoadingState:
          IndicatorWidgets.loadingWidget(context);
      }
    }, child: BlocBuilder<SignUpBloc, SignUpState>(builder: (context, state) {
      _signUpBloc = BlocProvider.of<SignUpBloc>(context);
    return Container(
        padding: const EdgeInsets.all(20.0),
        color: Colors.blue.shade800,
        child: ListView(
          children: <Widget>[
            Column(
              children: <Widget>[
                const SizedBox(
                  height: 50,
                ),
                Container(
                  width: 200,
                  child: const Icon(
                    Icons.whatshot,
                    size: 100.0,
                    color: Colors.white,
                  ),
                ),
                const SizedBox(
                  height: 50,
                ),
                ListTile(
                    title: CustomTextField(
                  controller: nameController,
                      icon: const Icon(
                        Icons.supervised_user_circle_rounded,
                        color: Colors.white30,
                      ),
                  onChanged: (text){
                    _signUpBloc.add(SignUpNameValidatorEvent(text));
                  },
                  errorMessage: nameErrorMessage,
                    hintText: "Full Name:",
                )),
                const Divider(
                  color: Colors.greenAccent,
                ),
                ListTile(
                    title: CustomTextField(
                  controller: emailController,
                  icon: const Icon(
                    Icons.email,
                    color: Colors.white30,
                  ),
                  onChanged: (text) {

                    _signUpBloc.add(SignUpEmailValidatorEvent(text));
                  },
                   hintText: "Email:",
                  errorMessage: emailErrorMessage,
                )),
                const Divider(
                  color: Colors.greenAccent,
                ),
                Visibility( visible: _signUpBloc.state is LoadingState,
                    child: Center(child: IndicatorWidgets.loadingWidget(context))
                ),
                ListTile(
                    title: CustomTextField(
                      onChanged: (text){
                        _signUpBloc.add(SignUpPasswordValidatorEvent(text));
                      },
                      icon:const Icon(
                        Icons.lock,
                        color: Colors.white30,
                      ),
                  controller: passwordController,
                  obscureText: true,
                      errorMessage: passwordErrorMessage,
                   hintText: "Password:",
                )),
                const Divider(
                  color: Colors.greenAccent,
                ),
                ListTile(
                    title: CustomTextField(
                        hintText: "Confirm Password:",
                        obscureText: true,
                      icon:const  Icon(
                        Icons.lock,
                        color: Colors.white30,
                      ),
                      controller: confirmPasswordController,
                      onChanged: (text){
                        _signUpBloc.add(SignUpConfirmPasswordValidatorEvent(text , passwordController!.text));
                      },
                      errorMessage: confirmPasswordErrorMessage,

                )),
                const Divider(
                  color: Colors.greenAccent,
                ),
                const SizedBox(
                  height: 20,
                ),
                Row(
                  children: <Widget>[
                    Expanded(
                      child: RaisedButton(
                        onPressed: () {
                          _signUpBloc.add(SignUpBtnTapEvent(
                              nameController!.text,
                              emailController!.text,
                              passwordController!.text));
                          Navigator.pushReplacement(
                              context,
                              MaterialPageRoute(
                                  builder: (context) => const SignUp()));
                        },
                        shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(30.0)),
                        color: Colors.green,
                        child: const Text(
                          'Sign Up',
                          style:
                              TextStyle(color: Colors.white70, fontSize: 16.0),
                        ),
                      ),
                    ),
                  ],
                ),
                const SizedBox(
                  height: 40,
                ),
                Column(
                  children: [
                    Text(
                      'Already have an account ?',
                      style: TextStyle(color: Colors.grey.shade500),
                    ),
                    TextButton(
                        onPressed: () {
                          Navigator.of(context).pushNamedAndRemoveUntil(
                              AppRoutes.login, (route) => false);
                        },
                        child: const Text('Sign In',
                            style: TextStyle(
                                color: Colors.white,
                                fontWeight: FontWeight.bold,
                                fontSize: 16))),
                  ],
                )
              ],
            ),
          ],
        ),
      );
    }));
  }
}

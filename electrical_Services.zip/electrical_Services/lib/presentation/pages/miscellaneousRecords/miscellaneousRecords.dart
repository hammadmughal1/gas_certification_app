import 'package:electrical_services/presentation/widgets/appbar.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

class MiscellaneousRecords extends StatefulWidget {
  const MiscellaneousRecords({Key? key}) : super(key: key);

  @override
  State<MiscellaneousRecords> createState() => _MiscellaneousRecordsState();
}

class _MiscellaneousRecordsState extends State<MiscellaneousRecords> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: body(context),
    );
  }
}

Widget body(context) {
  return Container(
    width: MediaQuery.of(context).size.width,
    height: MediaQuery.of(context).size.height,
    child: Column(
      children: <Widget>[
        appBar(context),
        const SizedBox(height: 20,),
        tilesBody(),
      ],
    ),
  );
}

Widget appBar(context){
  return GasCertificationAppBar.gasCertificationBar(isHomeScreen : false ,context: context , backgroundColor: Colors.lightBlue );
}

Widget tilesBody(){
  return Padding(
    padding: const EdgeInsets.all(8.0),
    child: Column(
      children: [
        ListTile(
          onLongPress: (){

          },
          shape: RoundedRectangleBorder(
            side:  const BorderSide(color: Colors.lightBlue, width: 2),
            borderRadius: BorderRadius.circular(15),
          ),
          leading: const CircleAvatar(
            radius: 15,
            backgroundColor: Colors.blue,
            child: Text('1'),
          ),
          title: const Text('Legionella Risk Assessment'),

          trailing: const Icon(
            Icons.arrow_forward_ios,
            size: 20,
            color: Colors.lightBlue,
          ),

        ),

        const SizedBox(height: 20,),
        ListTile(
          onLongPress: (){

          },
          shape: RoundedRectangleBorder(
            side:  const BorderSide(color: Colors.lightBlue, width: 2),
            borderRadius: BorderRadius.circular(15),

          ),
          leading: const CircleAvatar(
            radius: 15,
            backgroundColor: Colors.blue,
            child: Text('2'),

          ),
          title: const Text('Minor Electrical Works Record'),
          trailing: const Icon(
            Icons.arrow_forward_ios,
            size: 20,
            color: Colors.lightBlue,
          ),

        ),
        const SizedBox(height: 20,),
        ListTile(
          onLongPress: (){

          },
          shape: RoundedRectangleBorder(
            side:  const BorderSide(color: Colors.lightBlue, width: 2),
            borderRadius: BorderRadius.circular(15),

          ),
          leading: const CircleAvatar(
            radius: 15,
            backgroundColor: Colors.blue,
            child: Text('3'),

          ),
          title: const Text('Unvented Hot Water Cylinder Record'),
          trailing: const Icon(
            Icons.arrow_forward_ios,
            size: 20,
            color: Colors.lightBlue,
          ),

        ),

      ],
    ),
  );
}
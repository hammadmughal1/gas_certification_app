import 'package:electrical_services/presentation/widgets/appbar.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

class DomesticOilRecords extends StatefulWidget {
  const DomesticOilRecords({Key? key}) : super(key: key);

  @override
  State<DomesticOilRecords> createState() => _DomesticOilRecordsState();
}

class _DomesticOilRecordsState extends State<DomesticOilRecords> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: body(context),
    );
  }
}

Widget body(context) {
  return Container(
    width: MediaQuery.of(context).size.width,
    height: MediaQuery.of(context).size.height,
    child: Column(
      children: <Widget>[
        appBar(context),
        const SizedBox(height: 20,),
        tilesBody(),
      ],
    ),
  );
}

Widget appBar(context){
  return GasCertificationAppBar.gasCertificationBar(isHomeScreen : false ,context: context , backgroundColor: Colors.lightBlue );
}

Widget tilesBody(){
  return Padding(
    padding: const EdgeInsets.all(8.0),
    child: Column(
      children: [
        ListTile(
          onLongPress: (){

          },
          shape: RoundedRectangleBorder(
            side:  const BorderSide(color: Colors.lightBlue, width: 2),
            borderRadius: BorderRadius.circular(15),
          ),
          leading: const CircleAvatar(
            radius: 15,
            backgroundColor: Colors.blue,
            child: Text('1'),
          ),
          title: const Text('CD10 Oil Firing Installation Record'),

          trailing: const Icon(
            Icons.arrow_forward_ios,
            size: 20,
            color: Colors.lightBlue,
          ),

        ),

        const SizedBox(height: 20,),
        ListTile(
          onLongPress: (){

          },
          shape: RoundedRectangleBorder(
            side:  const BorderSide(color: Colors.lightBlue, width: 2),
            borderRadius: BorderRadius.circular(15),

          ),
          leading: const CircleAvatar(
            radius: 15,
            backgroundColor: Colors.blue,
            child: Text('2'),

          ),
          title: const Text('CD10 Oil Firing Servicing Record'),
          trailing: const Icon(
            Icons.arrow_forward_ios,
            size: 20,
            color: Colors.lightBlue,
          ),

        ),
        const SizedBox(height: 20,),
        ListTile(
          onLongPress: (){

          },
          shape: RoundedRectangleBorder(
            side:  const BorderSide(color: Colors.lightBlue, width: 2),
            borderRadius: BorderRadius.circular(15),

          ),
          leading: const CircleAvatar(
            radius: 15,
            backgroundColor: Colors.blue,
            child: Text('3'),

          ),
          title: const Text('CD12 Landlord Oil Installation Check'),
          trailing: const Icon(
            Icons.arrow_forward_ios,
            size: 20,
            color: Colors.lightBlue,
          ),

        ),
        const SizedBox(height: 20,),
        ListTile(
          onLongPress: (){

          },
          shape: RoundedRectangleBorder(
            side:  const BorderSide(color: Colors.lightBlue, width: 2),
            borderRadius: BorderRadius.circular(15),

          ),
          leading: const CircleAvatar(
            radius: 15,
            backgroundColor: Colors.blue,
            child: Text('4'),

          ),
          title: const Text('CD12 Warning and Advice Notice'),
          trailing: const Icon(
            Icons.arrow_forward_ios,
            size: 20,
            color: Colors.lightBlue,
          ),

        ),
        const SizedBox(height: 20,),
        ListTile(
          onLongPress: (){

          },
          shape: RoundedRectangleBorder(
            side:  const BorderSide(color: Colors.lightBlue, width: 2),
            borderRadius: BorderRadius.circular(15),

          ),
          leading: const CircleAvatar(
            radius: 15,
            backgroundColor: Colors.blue,
            child: Text('5'),

          ),
          title: const Text('T1133D Domestic Oil Storage'),
          trailing: const Icon(
            Icons.arrow_forward_ios,
            size: 20,
            color: Colors.lightBlue,
          ),

        ),
      ],
    ),
  );
}
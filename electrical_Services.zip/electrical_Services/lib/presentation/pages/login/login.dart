import 'package:electrical_services/base/routes.dart';
import 'package:electrical_services/presentation/bloc/LoginBloc/login_bloc.dart';
import 'package:electrical_services/presentation/pages/homeScreen/homeScreen.dart';

import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

import '../../widgets/CustomTextField.dart';
import '../sign_up/signup.dart';

class Login extends StatefulWidget {
  const Login({Key? key}) : super(key: key);

  @override
  State<Login> createState() => _LoginState();
}

class _LoginState extends State<Login> {
  late LoginBloc _loginBloc;
  TextEditingController? emailController;
  TextEditingController? passwordController;
  String emailErrorMessage = "";
  String passwordErrorMessage = "";
  String errorMessage = "";
  bool isDisabled = false;
  bool isSignedTap = false;

  @override
  void initState() {
    // TODO: implement initState
    emailController = TextEditingController();
    passwordController = TextEditingController();
    super.initState();
  }
  @override
  void dispose() {
    // TODO: implement dispose
    emailController!.dispose();
    passwordController!.dispose();
    super.dispose();
  }
  @override
  Widget build(BuildContext context) {
    return BlocProvider(
        create: (context) {
          return LoginBloc();
        },
        child: Scaffold(body: _buildPageContent(context)));
  }

  void sendToDashboard(){
    Navigator.of(context)
        .pushReplacementNamed(AppRoutes.homeScreen, arguments: null);
  }

  Widget _buildPageContent(BuildContext context) {
    return BlocListener<LoginBloc, LoginState>(listener: (context, state) {
      switch (state.runtimeType) {
        case LoginBtnTapState:
          errorMessage = (state as LoginBtnTapState).response.errorMessage;
          break;
        case LoginEmailValidatorState:
          emailErrorMessage = (state as LoginEmailValidatorState).validationMessage;
          break;
        case LoginPasswordValidatorState:
          emailErrorMessage = (state as LoginPasswordValidatorState).validationMessage;
          break;
        case LoginBtnTapSuccessState:
          sendToDashboard();
          break;
      }
    }, child: BlocBuilder<LoginBloc, LoginState>(builder: (context, state) {
      _loginBloc = BlocProvider.of<LoginBloc>(context);
      return Container(
        padding: const EdgeInsets.all(20.0),
        color: Colors.blue.shade800,
        child: ListView(
          children: <Widget>[
            Column(
              children: <Widget>[
                const SizedBox(
                  height: 50,
                ),
                Container(
                  width: 200,
                  child:const Icon(
                    Icons.whatshot,
                    size: 100.0,
                    color: Colors.white,
                  ),
                ),
                const SizedBox(
                  height: 50,
                ),
                ListTile(
                    title: CustomTextField(
                      controller: emailController,
                      onChanged: (text){
                      _loginBloc.add(LoginEmailValidatorEvent(text));
                      },
                  errorMessage: emailErrorMessage,

                  icon: const Icon(
                    Icons.verified_user,
                    color: Colors.white30,
                  ),
                  hintText: "Email Address:",
                )),
                const Divider(
                  color: Colors.greenAccent,
                ),
                ListTile(
                    title: CustomTextField(
                      controller: passwordController,
                      onChanged: (text){
                        _loginBloc.add(LoginPasswordValidatorEvent(text));

                      },
                  errorMessage: passwordErrorMessage,
                  obscureText: true,
                  icon: const Icon(
                    Icons.lock,
                    color: Colors.white30,
                  ),
                  hintText: "Password:",
                )),
                const Divider(
                  color: Colors.greenAccent,
                ),
                Text(
                  errorMessage,
                  style:const TextStyle(color: Colors.redAccent),
                ),
                const SizedBox(
                  height: 20,
                ),
                Row(
                  children: <Widget>[

                    Expanded(
                      child: RaisedButton(
                        disabledColor: Colors.red,
                        onPressed: () {
                           isDisabled= (emailController!.text != "" && passwordController!.text != "" && emailErrorMessage == "" && passwordErrorMessage == "" ) ? false : true;

                           isDisabled == false ?
                          _loginBloc.add(LoginBtnTapEvent(emailController!.text, passwordController!.text)):
                           setState(() {
                             isSignedTap = true;
                           });
                          // Navigator.pushReplacement(
                          //     context,
                          //     MaterialPageRoute(
                          //         builder: (context) => const HomeScreen()));
                        },
                        shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(30.0)),
                        color: (emailController?.text != "" && passwordController?.text != "" && emailErrorMessage == "" && passwordErrorMessage == "" ) ? Colors.green : Colors.grey,
                        child: const Text(
                          'Login',
                          style:
                              TextStyle(color: Colors.white70, fontSize: 16.0),
                        ),
                      ),
                    ),
                  ],
                ),
                const SizedBox(
                  height: 40,
                ),
                Column(
                  children: [
                    Text(
                      'Not Register Yet ?',
                      style: TextStyle(color: Colors.grey.shade500),
                    ),
                    TextButton(
                        onPressed: () {
                          Navigator.of(context).pushNamedAndRemoveUntil(
                              AppRoutes.signUp, (route) => false);
                        },
                        child: const Text('Sign Up',
                            style: TextStyle(
                                color:  Colors.white,
                                fontWeight: FontWeight.bold,
                                fontSize: 16))),
                  ],
                )
              ],
            ),
          ],
        ),
      );
    }));
  }
}

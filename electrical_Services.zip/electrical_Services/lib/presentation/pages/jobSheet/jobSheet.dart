import 'package:electrical_services/presentation/widgets/appbar.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

class JobSheet extends StatefulWidget {
  const JobSheet({Key? key}) : super(key: key);

  @override
  State<JobSheet> createState() => _JobSheetState();
}

class _JobSheetState extends State<JobSheet> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: body(context),
    );
  }
}

Widget body(context) {
  return Container(
    width: MediaQuery.of(context).size.width,
    height: MediaQuery.of(context).size.height,
    child: Column(
      children: <Widget>[
        appBar(context),
        const SizedBox(height: 20,),
        tilesBody(),
      ],
    ),
  );
}

Widget appBar(context){
  return GasCertificationAppBar.gasCertificationBar(isHomeScreen : false ,context: context , backgroundColor: Colors.lightBlue );
}

Widget tilesBody(){
  return Padding(
    padding: const EdgeInsets.all(8.0),
    child: Column(
      children: [
        ListTile(
          onLongPress: (){

          },
          shape: RoundedRectangleBorder(
            side:  const BorderSide(color: Colors.lightBlue, width: 2),
            borderRadius: BorderRadius.circular(15),
          ),
          leading: const CircleAvatar(
            radius: 15,
            backgroundColor: Colors.blue,
            child: Text('1'),
          ),
          title: const Text('Homeowner Gas Safety Records'),

          trailing: const Icon(
            Icons.arrow_forward_ios,
            size: 20,
            color: Colors.lightBlue,
          ),

        ),

        const SizedBox(height: 20,),
        ListTile(
          onLongPress: (){

          },
          shape: RoundedRectangleBorder(
            side:  const BorderSide(color: Colors.lightBlue, width: 2),
            borderRadius: BorderRadius.circular(15),

          ),
          leading: const CircleAvatar(
            radius: 15,
            backgroundColor: Colors.blue,
            child: Text('2'),

          ),
          title: const Text('Landlord Gas Safety Records'),
          trailing: const Icon(
            Icons.arrow_forward_ios,
            size: 20,
            color: Colors.lightBlue,
          ),

        ),
        const SizedBox(height: 20,),
        ListTile(
          onLongPress: (){

          },
          shape: RoundedRectangleBorder(
            side:  const BorderSide(color: Colors.lightBlue, width: 2),
            borderRadius: BorderRadius.circular(15),

          ),
          leading: const CircleAvatar(
            radius: 15,
            backgroundColor: Colors.blue,
            child: Text('3'),

          ),
          title: const Text('Gas Warning Notice'),
          trailing: const Icon(
            Icons.arrow_forward_ios,
            size: 20,
            color: Colors.lightBlue,
          ),

        ),
        const SizedBox(height: 20,),
        ListTile(
          onLongPress: (){

          },
          shape: RoundedRectangleBorder(
            side:  const BorderSide(color: Colors.lightBlue, width: 2),
            borderRadius: BorderRadius.circular(15),

          ),
          leading: const CircleAvatar(
            radius: 15,
            backgroundColor: Colors.blue,
            child: Text('4'),

          ),
          title: const Text('Gas Service Records'),
          trailing: const Icon(
            Icons.arrow_forward_ios,
            size: 20,
            color: Colors.lightBlue,
          ),

        ),
        const SizedBox(height: 20,),
        ListTile(
          onLongPress: (){

          },
          shape: RoundedRectangleBorder(
            side:  const BorderSide(color: Colors.lightBlue, width: 2),
            borderRadius: BorderRadius.circular(15),

          ),
          leading: const CircleAvatar(
            radius: 15,
            backgroundColor: Colors.blue,
            child: Text('5'),

          ),
          title: const Text('Gas BreakDown Records'),
          trailing: const Icon(
            Icons.arrow_forward_ios,
            size: 20,
            color: Colors.lightBlue,
          ),

        ),
      ],
    ),
  );
}
import 'package:electrical_services/base/routes.dart';
import 'package:electrical_services/presentation/widgets/appbar.dart';
import 'package:flutter/material.dart';

class RecordScreen extends StatefulWidget {
  const RecordScreen({Key? key}) : super(key: key);

  @override
  State<RecordScreen> createState() => _RecordScreenState();
}

class _RecordScreenState extends State<RecordScreen> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: body(context),
    );
  }
}

Widget body(context) {
  return Container(
    width: MediaQuery.of(context).size.width,
    height: MediaQuery.of(context).size.height,
    child: Column(
      children: <Widget>[
        appBar(context),
        const SizedBox(height: 20,),
        tilesBody(context),
      ],
    ),
  );
}

Widget appBar(context){
  return GasCertificationAppBar.gasCertificationBar(isHomeScreen : false ,context: context , backgroundColor: Colors.lightBlue );
}

Widget tilesBody(context){
  return Padding(
    padding: const EdgeInsets.all(8.0),
    child: Column(
      children: [
        ListTile(
          onTap: (){
            Navigator.of(context).pushNamed(AppRoutes.domesticRecordScreen);
          },
          onLongPress: (){

          },
          shape: RoundedRectangleBorder(
            side:  const BorderSide(color: Colors.lightBlue, width: 2),
            borderRadius: BorderRadius.circular(15),
          ),
          leading: const CircleAvatar(
            radius: 15,
            backgroundColor: Colors.blue,
            child: Text('1'),
          ),
          title: const Text('Domestic Records'),

          trailing: const Icon(
            Icons.arrow_forward_ios,
            size: 20,
            color: Colors.lightBlue,
          ),

        ),

        const SizedBox(height: 20,),
        ListTile(
          onLongPress: (){

          },
          shape: RoundedRectangleBorder(
            side:  const BorderSide(color: Colors.lightBlue, width: 2),
            borderRadius: BorderRadius.circular(15),

          ),
          leading: const CircleAvatar(
            radius: 15,
            backgroundColor: Colors.blue,
            child: Text('2'),

          ),
          onTap: (){
            Navigator.of(context).pushNamed(AppRoutes.nonDomesticRecordScreen);
          },
          title: const Text('Non Domestic Records'),
          trailing: const Icon(
            Icons.arrow_forward_ios,
            size: 20,
            color: Colors.lightBlue,
          ),

        ),
        const SizedBox(height: 20,),
        ListTile(
          onLongPress: (){

          },
          shape: RoundedRectangleBorder(
            side:  const BorderSide(color: Colors.lightBlue, width: 2),
            borderRadius: BorderRadius.circular(15),

          ),
          leading: const CircleAvatar(
            radius: 15,
            backgroundColor: Colors.blue,
            child: Text('3'),

          ),
          onTap: (){
            Navigator.of(context).pushNamed(AppRoutes.domesticOilRecordScreen);
          },
          title: const Text('Domestic Oil Records'),
          trailing: const Icon(
            Icons.arrow_forward_ios,
            size: 20,
            color: Colors.lightBlue,
          ),

        ),
        const SizedBox(height: 20,),
        ListTile(
          onLongPress: (){

          },
          shape: RoundedRectangleBorder(
            side:  const BorderSide(color: Colors.lightBlue, width: 2),
            borderRadius: BorderRadius.circular(15),

          ),
          leading: const CircleAvatar(
            radius: 15,
            backgroundColor: Colors.blue,
            child: Text('4'),

          ),
          onTap: (){
            Navigator.of(context).pushNamed(AppRoutes.miscellaneousRecordScreen);
          },
          title: const Text('Miscellaneous Records'),
          trailing: const Icon(
            Icons.arrow_forward_ios,
            size: 20,
            color: Colors.lightBlue,
          ),

        ),
        const SizedBox(height: 20,),
        ListTile(
          onLongPress: (){

          },
          shape: RoundedRectangleBorder(
            side:  const BorderSide(color: Colors.lightBlue, width: 2),
            borderRadius: BorderRadius.circular(15),

          ),
          leading: const CircleAvatar(
            radius: 15,
            backgroundColor: Colors.blue,
            child: Text('5'),

          ),
          onTap: (){
            Navigator.of(context).pushNamed(AppRoutes.jobSheetScreen);
          },
          title: const Text('Job Sheet'),
          trailing: const Icon(
            Icons.arrow_forward_ios,
            size: 20,
            color: Colors.lightBlue,
          ),

        ),
      ],
    ),
  );
}
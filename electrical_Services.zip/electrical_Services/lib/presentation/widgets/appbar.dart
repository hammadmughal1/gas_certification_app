

import 'package:flutter/material.dart';

import '../../base/images.dart';

class GasCertificationAppBar extends StatefulWidget {
  const GasCertificationAppBar({Key? key}) : super(key: key);

  @override
  State<GasCertificationAppBar> createState() => _GasCertificationAppBarState();


  static Widget gasCertificationBar(
      {Function? leadingButtonAction,
        required bool isHomeScreen,
        Function? trailingButtonAction,
        required BuildContext context,
        Color? textColor,
        Color? backgroundColor,
        String? title,
        double? height,
        TextStyle? titleStyle,
        bool containSafeArea = false,
        double contentBottomPadding = 0}) {

    return Container(
      height:90,
      width: MediaQuery.of(context).size.width,
      color: backgroundColor,

      child: Row(
        children:  <Widget>[
          const Padding(padding: EdgeInsets.fromLTRB(10, 30, 0, 10)),
          GestureDetector(
            onTap: (){
              Navigator.of(context).pop();
            },
            child:Visibility(
              visible: isHomeScreen == false ? true : false ,
              child: const CircleAvatar(

                  backgroundColor: Colors.transparent,
                  backgroundImage: null,
                  child : Center(
                      child: Icon(Icons.keyboard_backspace_outlined) )

              ),
            ),
          ),
          const Spacer(),
          const Center(
              child: Text('Gas Certification App' , style: TextStyle(
                fontSize: 15  , color: Colors.white
              ),), ),


          const Spacer(),

          const CircleAvatar(
              backgroundColor: Colors.transparent,
              backgroundImage: null,
              child : Center(
                  child: Icon(Icons.home) )

          ),
          const CircleAvatar(
              backgroundColor: Colors.transparent,
              backgroundImage: null,
              child : Center(
                  child: Icon(Icons.logout) )

          ),

        ],
      ),
    );
  }
}


class _GasCertificationAppBarState extends State<GasCertificationAppBar> {
  @override
  Widget build(BuildContext context) {
    return Container();
  }
}


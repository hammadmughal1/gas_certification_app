
import 'package:flutter/material.dart';

class IndicatorWidgets {
  static Widget loadingWidget(BuildContext context) {
    return CircularProgressIndicator(
      strokeWidth: 6,
      valueColor: AlwaysStoppedAnimation(Theme
          .of(context)
          .primaryColor),
    );
  }
}
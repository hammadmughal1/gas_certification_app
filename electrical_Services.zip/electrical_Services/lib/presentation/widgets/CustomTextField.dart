import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

class CustomTextField extends StatelessWidget {
  final String? hintText;
  final String? labelText;
  final Icon? icon;
  final Function(String)? onChanged;
  final Function()? onEditingComplete;
  final Function()? bioMetricClick;
  final String errorMessage;
  final TextEditingController? controller;
  final TextInputType? keyboardType;
  final bool? obscureText;
  final Widget? suffixIcon;
  final FocusNode? focusNode;
  final bool? autocorrect;
  final FormFieldValidator<String>? validator;
  final bool? readOnly;
  final VoidCallback? ontap;
  final Color? labelColor;
  final int? maxLines;
  final Color? backgroundColor;
  final bool? hasBorder;
  final int? maxlength;
  final bool? enabled;
  final Widget? prefixIcon;

  CustomTextField(
      {this.hintText,
        this.onChanged,
        required this.errorMessage,
        this.controller,
        this.keyboardType,
        this.suffixIcon,
        this.obscureText = false,
        this.focusNode,
        this.autocorrect = false,
        this.validator,
        this.labelText,
        this.readOnly = false,
        this.ontap,
        this.labelColor,
        this.maxLines = 1,
        this.backgroundColor,
        this.hasBorder = true,
        this.onEditingComplete,
        this.bioMetricClick,
        this.maxlength,
        this.enabled = true,
        this.prefixIcon,
      this.icon});

  @override
  Widget build(BuildContext context) {
    return Container(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: <Widget>[
          Container(
            height:40,
        decoration: BoxDecoration(color: backgroundColor ?? Colors.transparent),

            child: Center(
              child: Stack(
                alignment: Alignment.centerLeft,
                children: <Widget>[
                  TextFormField(
                    maxLines: maxLines,
                    textAlignVertical: TextAlignVertical.top,
                    focusNode: focusNode,
                    controller: controller,
                    onChanged: (text) {
                      onChanged!(text);
                    },
                    style: const TextStyle(color: Colors.white70 , fontSize: 15),
                    onEditingComplete: onEditingComplete,
                    readOnly: readOnly!,
                    keyboardType: keyboardType,
                    maxLength: maxlength,
                    decoration: InputDecoration(

                      counterText: "",
                      contentPadding:const  EdgeInsets.fromLTRB(
                          08, 10, 30, 10),
                      hintText: hintText,
                        hintStyle:const TextStyle(color: Colors.white70 , fontSize: 13),
                        icon: icon!,
                      border: hasBorder!
                          ? OutlineInputBorder(
                          borderSide:
                          const BorderSide(width: 0, color: Colors.white , ),
                          borderRadius: BorderRadius.circular(10))
                          : InputBorder.none,
                    ),
                    obscureText: obscureText!,
                    autocorrect: autocorrect!,
                    validator: validator,
                    onTap: ontap,
                    enabled: enabled,
                  ),
                  Container(
                    width: 40,
                    alignment: Alignment.center,
                    child: prefixIcon,
                  ),
                  GestureDetector(
                    onTap: bioMetricClick,
                    child: Container(
                      padding: EdgeInsets.only(right: 6),
                      alignment: Alignment.centerRight,
                      child: suffixIcon,
                    ),
                  )
                ],
              ),
            ),
          ),
          const SizedBox(height: 10,),
          Text(
            errorMessage.isEmpty ? "" : errorMessage, style: const TextStyle(color: Colors.redAccent , fontSize: 13),
          )
        ],
      ),
    );
  }
}

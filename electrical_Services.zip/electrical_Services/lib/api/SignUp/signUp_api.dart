import 'package:dio/dio.dart';

import '../../models/GeneralResponse.dart';

class SignUpApi{
  final Dio dio;
  final String _baseurl;

  SignUpApi(this.dio , this._baseurl);

  Future<GeneralResponse> signUpWithEmail(String name , String email , String password) async {
    String errorMessage = '';

  Map<String, dynamic> queryData = {
    "name": name,
    "email": email,
    "password": password,
  };

  Response response = await dio.post("https://950d-111-119-187-24.in.ngrok.io/api/signup" ,data: queryData);
  if(response.statusCode !=200){
    errorMessage = response.data["message"];
  }
  return GeneralResponse(response: response, errorMessage: errorMessage);
}

  Future<GeneralResponse> signInWithEmail(String email , String password) async {
    String errorMessage = '';

    Map<String, dynamic> queryData = {
      "email": email,
      "password": password,
    };

    Response response = await dio.post("https://950d-111-119-187-24.in.ngrok.io/api/signin" ,data: queryData);
    if(response.statusCode !=200){
      errorMessage = response.data["message"];
    }
    return GeneralResponse(response: response, errorMessage: errorMessage);
  }
}
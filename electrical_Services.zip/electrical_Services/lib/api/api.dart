import 'package:dio/dio.dart';

import 'SignUp/signUp_api.dart';

class API{
  final SignUpApi signUpApi;

  API({required Dio dio, required String baseUrl})
  : signUpApi = SignUpApi(dio , baseUrl);
}
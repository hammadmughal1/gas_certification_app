class GeneralResponse<T> {
  final T response;
  final String errorMessage;

  GeneralResponse({required this.response, required this.errorMessage});
}

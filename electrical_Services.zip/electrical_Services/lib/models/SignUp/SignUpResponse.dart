/// name : "hellowword"
/// email : "okaygoogle@gmail.com"
/// password : "okay"

class SignUpResponse {
  SignUpResponse({
      String? name, 
      String? email, 
      String? password,}){
    _name = name;
    _email = email;
    _password = password;
}

  SignUpResponse.fromJson(dynamic json) {
    _name = json['name'];
    _email = json['email'];
    _password = json['password'];
  }
  String? _name;
  String? _email;
  String? _password;
SignUpResponse copyWith({  String? name,
  String? email,
  String? password,
}) => SignUpResponse(  name: name ?? _name,
  email: email ?? _email,
  password: password ?? _password,
);
  String? get name => _name;
  String? get email => _email;
  String? get password => _password;

  Map<String, dynamic> toJson() {
    final map = <String, dynamic>{};
    map['name'] = _name;
    map['email'] = _email;
    map['password'] = _password;
    return map;
  }

}
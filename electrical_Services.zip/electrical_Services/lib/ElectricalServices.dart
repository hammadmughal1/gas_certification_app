import 'package:animated_splash_screen/animated_splash_screen.dart';
import 'package:electrical_services/base/images.dart';
import 'package:electrical_services/presentation/pages/domesticOilRecords/domesticOilRecords.dart';
import 'package:electrical_services/presentation/pages/domesticRecords/domesticsRecords.dart';
import 'package:electrical_services/presentation/pages/homeScreen/homeScreen.dart';
import 'package:electrical_services/presentation/pages/jobSheet/jobSheet.dart';
import 'package:electrical_services/presentation/pages/login/login.dart';
import 'package:electrical_services/presentation/pages/miscellaneousRecords/miscellaneousRecords.dart';
import 'package:electrical_services/presentation/pages/nonDomesticRecords/nonDomesticRecords.dart';
import 'package:electrical_services/presentation/pages/recordScreen/recordScreen.dart';
import 'package:electrical_services/presentation/pages/sign_up/signup.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

import 'base/enum.dart';
import 'base/routes.dart';

class ElectricalServices extends StatefulWidget {
  const ElectricalServices({Key? key}) : super(key: key);

  @override
  State<ElectricalServices> createState() => _ElectricalServicesState();
}

class _ElectricalServicesState extends State<ElectricalServices> {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
        onGenerateRoute: (settings) {
          switch (settings.name) {
            case AppRoutes.login:
              return CupertinoPageRoute(
                  builder: (_) => const Login(), settings: settings);
            case AppRoutes.signUp:
              return CupertinoPageRoute(
                  builder: (_) => const SignUp(), settings: settings);
            case AppRoutes.homeScreen:
              return CupertinoPageRoute(
                  builder: (_) => const HomeScreen(), settings: settings);
            case AppRoutes.recordScreen:
              return CupertinoPageRoute(
                  builder: (_) => const RecordScreen(), settings: settings);
            case AppRoutes.domesticRecordScreen:
              return CupertinoPageRoute(
                  builder: (_) => const DomesticRecords(), settings: settings);
            case AppRoutes.nonDomesticRecordScreen:
              return CupertinoPageRoute(
                  builder: (_) => const NonDomesticRecords(), settings: settings);
            case AppRoutes.domesticOilRecordScreen:
              return CupertinoPageRoute(
                  builder: (_) => const DomesticOilRecords(), settings: settings);
            case AppRoutes.miscellaneousRecordScreen:
              return CupertinoPageRoute(
                  builder: (_) => const MiscellaneousRecords(), settings: settings);
            case AppRoutes.jobSheetScreen:
              return CupertinoPageRoute(
                  builder: (_) => const JobSheet(), settings: settings);

          }
        },
    home: AnimatedSplashScreen(
      nextScreen: const Login(),
      duration: 2500,
      splash: const Icon(Icons.whatshot , size: 140, color: Colors.white,),
        splashTransition: SplashTransition.scaleTransition,
        backgroundColor: Colors.blue.shade800,
    ),);
  }
}

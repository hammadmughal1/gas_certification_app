import 'package:electrical_services/helpers/getit.dart';
import 'package:electrical_services/models/GeneralResponse.dart';
import 'package:get_it/get_it.dart';

import '../../../api/api.dart';

class AuthManager{

  Future<GeneralResponse> signUpWithEmailAndPassword(String name , String email , String password  ) async{
       GeneralResponse response =  await GetIt.instance<API>().signUpApi.signUpWithEmail(name, email, password);
       return response;

  }

  Future<GeneralResponse> signInWithEmailAndPassword(String email , String password  ) async{
    GeneralResponse response =  await GetIt.instance<API>().signUpApi.signInWithEmail(email, password);
    return response;

  }

}
import 'package:get_it/get_it.dart';

import 'implementations/AuthManager/auth.dart';

class Manager{
  final AuthManager authManager;
  Manager()
    : authManager = AuthManager();


}

Manager get manager => GetIt.instance<Manager>();
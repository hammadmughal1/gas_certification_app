class AppImages {
  ///icons
  static const splashLogo = 'assets/icons/logo.png';

  ///fonts

  ///images
}
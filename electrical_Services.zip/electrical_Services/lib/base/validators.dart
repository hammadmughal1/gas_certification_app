import 'package:form_field_validator/form_field_validator.dart';


class GasCertificationValidators {
  /// returns an email validation error if it doesn't match and if is empty string
  static String emailValidatorMulti(String email) {

    String? response = MultiValidator([
      RequiredValidator(errorText:"The Email field is required."),
      EmailValidator(errorText: "The email is not valid email.")
    ]).call(email.trim().toLowerCase());

    return response == null ? "" : response;
  }

  /// returns an email validation error if it doesn't match
  // static String? emailValidator(String email) {
  //   String wrongEmail = "The Email field is required";
  //   return EmailValidator(
  //       errorText: wrongEmail
  //       .call(email.trim().toLowerCase());
  // }

  /// returns an password validation error if it doesn't match
  static String passwordValidator(String password) {


    String? response = MultiValidator([
      RequiredValidator(errorText: "The password is required"),
      LengthRangeValidator(min: 8, max: 30, errorText: "Password must be between 8-30 digits")
    ]).call(password);

    return response ?? "";
  }

  static String requiredValidator(String name) {


    String? response = MultiValidator([
      RequiredValidator(errorText: "The password is required"),

    ]).call(name);

    return response ?? "";
  }

  /// return on reset password validation error
  static String resetPasswordValidator(String resetPassword){
    String  pattern = r'^(?=.*?[A-Z])(?=.*?[a-z])(?=.*?[0-9])(?=.*?[!@#\$&*~]).{8,}$';
    RegExp regExp = new RegExp(pattern);
    bool error= regExp.hasMatch(resetPassword);
    if(error==true)
    {
      return "";
    }
    else{
      return "Invalid password format";
    }
  }
  static String resetOTPValidator(String otp){
    if(otp.length==6)
    {
      return "";
    }
    else{
      return "Invalid OTP format";
    }
  }
}


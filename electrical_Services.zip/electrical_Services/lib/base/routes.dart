class AppRoutes  {

  static const splashscreen = '/splashscreen';
  static const login = '/login';
  static const signUp = '/signup';
  static const homeScreen = '/homeScreen';
  static const recordScreen = '/recordScreen';
  static const domesticRecordScreen = '/domesticRecordScreen';
  static const domesticOilRecordScreen = '/domesticOilRecordScreen';
  static const nonDomesticRecordScreen = '/nonDomesticRecordScreen';
  static const miscellaneousRecordScreen = '/miscellaneousRecordScreen';
  static const jobSheetScreen = '/jobSheetScreen';

}

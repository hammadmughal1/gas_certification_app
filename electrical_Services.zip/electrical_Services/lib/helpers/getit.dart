import 'package:dio/dio.dart';
import 'package:get_it/get_it.dart';

import '../api/api.dart';
import '../manager/manager.dart';

class GetItHelper {
  static void init() {
    GetIt getIt = GetIt.instance;

    getIt.registerLazySingleton(() => Manager());

    var dio = Dio(BaseOptions(
      connectTimeout: 60000,
      receiveTimeout: 60000,
      sendTimeout: 6000000,
      validateStatus: (status) {
        return true;
      },
    ));
    getIt.registerLazySingleton(
            () => API(dio: dio, baseUrl: "oja"));
  }

}

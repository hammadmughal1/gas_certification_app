package com.example.electrical_services

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
